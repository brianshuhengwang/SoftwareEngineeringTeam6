from tkinter import *

class chooseTopic(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.chooseT()

    def chooseT(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=30, pady=15)

        img = PhotoImage(file="warningsign.gif")
        warningSign = Label(self, image=img, background="#fff")
        warningSign.photo = img
        warningSign.grid(in_=BigFrame, row=0)

        BlablaBox = Frame(self, background="#fff")
        BlablaBox.grid(in_=BigFrame, row=0, column=1, padx=30)
        Bla1 = Label(self, text="No topic was chosen.", font=('MS', 14), background="#fff")
        Bla1.grid(in_=BlablaBox, row=0)
        Bla2 = Label(self, text="Please choose a topic.", font=('MS', 14), background="#fff")
        Bla2.grid(in_=BlablaBox, row=1)
        OKbutton = Button(self, text="OK", width=8, command= self.close_window, background="#000", foreground="#fff",
                          activebackground="#000", activeforeground="#fff", relief=FLAT)
        OKbutton.grid(in_=BlablaBox, row=2, pady=10)

    def close_window(self):
        self.master.destroy()
