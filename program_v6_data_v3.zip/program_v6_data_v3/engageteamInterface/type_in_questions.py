from tkinter import *
from database import sqlQuestion
from database import sqlTopic
from engageteamInterface import popup_emptys

buttonWidth = 8
buttonPadx = 5
entryWidth = 40
padY = 10
quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()

class TypeQuestions(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.displayTypeQuestions()

    def displayTypeQuestions(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)
            
        # Question
        QuestionLabel = Label(self, text="Question:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        QuestionLabel.grid(in_=BigFrame, row=0, sticky=W)
        Q = StringVar()
        QuestionBox = Entry(self, textvariable=Q, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        QuestionBox.grid(in_=BigFrame, row=1)
            
        # Correct Answer
        CorrectLabel = Label(self, text="Correct answer:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        CorrectLabel.grid(in_=BigFrame, row=2, sticky=W)
        C = StringVar()
        CorrectBox = Entry(self, textvariable=C, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        CorrectBox.grid(in_=BigFrame, row=3)
            
        # False Answer 1
        False1Label = Label(self, text="False answer 1:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        False1Label.grid(in_=BigFrame, row=4, sticky=W)
        F1 = StringVar()
        False1Box = Entry(self, textvariable=F1, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        False1Box.grid(in_=BigFrame, row=5)

        # False Answer 2
        False2Label = Label(self, text="False answer 2:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        False2Label.grid(in_=BigFrame, row=6, sticky=W)
        F2 = StringVar()
        False2Box = Entry(self, textvariable=F2, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        False2Box.grid(in_=BigFrame, row=7)

        # Topics
        TopicLabel = Label(self, text="Topics:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        TopicLabel.grid(in_=BigFrame, row=8, sticky=W)
        BoxAndScroll = Frame(self)
        BoxAndScroll.grid(in_=BigFrame, row=9)
        TopicBox = Listbox(self, selectmode=EXTENDED, activestyle="none", height=6, width=50, bd=2, relief=GROOVE, selectbackground="#960000")
        Scroll = Scrollbar(self, command=TopicBox.yview)
        Scroll.configure(background="#000", activebackground="#000", troughcolor="#fff")
        TopicBox.configure(yscrollcommand=Scroll.set)
        TopicBox.grid(in_=BoxAndScroll, row=0)
        Scroll.grid(in_=BoxAndScroll, row=0, column=1, sticky=N+S)
        global TopicList # do not remove this & do not put = after it
        TopicList = topic.select_all()
        for item in TopicList:
            item = item[1]
            TopicBox.insert(END, item)
        
        # Buttons
        ButtonBox = Frame(self, pady=padY+3, background="#fff")
        ButtonBox.grid(in_=BigFrame, row=10)
        SaveButton = Button(self, text="Save", width=buttonWidth, command=lambda: self.readInQuestion(Q, C, F1, F2, TopicBox), background="#000",
                            foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        SaveButton.grid(in_=ButtonBox, row=0, column=0, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command= self.close_window, background="#000", foreground="#fff",
                              relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox, row=0, column=1, padx=buttonPadx)

    def close_window(self):
        self.master.destroy()

    def readInQuestion(self, Q, C, F1, F2, TB):
        qus_body = Q.get()
        correct_ans = C.get()
        false_ans1 = F1.get()
        false_ans2 = F2.get()
        if (qus_body=="") or (correct_ans=="") or (false_ans1=="") or (false_ans2==""):
            self.pop_up_warning()
            return
        index = TB.curselection()
        topic_select = []
        for item in index:
            topic_select.append(TopicList[item][0])
        qus_topic = str(topic_select)
        qus_topic = qus_topic.strip("[")
        qus_topic = qus_topic.strip("]")
        quiz.add_question(qus_body, correct_ans, false_ans1, false_ans2, qus_topic)
        self.displayTypeQuestions() # clears the fields

    def pop_up_warning(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Warning")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.configure(background="#fff")
        self.newWindow.minsize(width=500, height=150)
        self.newWindow.grab_set()
        self.newWindow.focus()
        self.app = popup_emptys.emptyFields(self.newWindow)
