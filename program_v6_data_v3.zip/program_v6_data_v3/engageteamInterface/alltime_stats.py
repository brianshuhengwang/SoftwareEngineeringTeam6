from tkinter import *
from database import sqlQuestion
from database import sqlTopic
from database import func
from operator import itemgetter

ListHeight = 15
buttonWidth = 12
buttonPadx = 3
quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()
function = func.Function


QuestionStats = function().question_stat()
# print(QuestionStats)


class stats(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.displayStats()

    def displayStats(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=30, pady=20)
        # heading
        AlltimeTag = Label(self, text="All-time statistics", font=('Georgia', 18, 'bold'), background="#fff")
        AlltimeTag.grid(in_=BigFrame, row=0)
        # statbox & texts over the columns
        StatBox = Frame(self, background="#fff")
        StatBox.grid(in_=BigFrame, row=1, pady=15)
        QLabel = Label(self, text="Question", background="#fff", font=('Georgia', 12))
        QLabel.grid(in_=StatBox, row=0)
        TLabel = Label(self, text="Times \nasked", background="#fff", font=('Georgia', 8))
        TLabel.grid(in_=StatBox, row=0, column=1)
        CLabel = Label(self, text="Answered \ncorrectly", background="#fff", font=('Georgia', 8))
        CLabel.grid(in_=StatBox, row=0, column=2)
        ALabel = Label(self, text="Not \nanswered", background="#fff", font=('Georgia', 8))
        ALabel.grid(in_=StatBox, row=0, column=3)

        # listboxes        
        self.listbox1 = Listbox(self, width=50, height=ListHeight, activestyle="none", bd=2, relief=GROOVE,
                                selectbackground="#960000")
        self.listbox1.grid(in_=StatBox, row=1, column=0)
        self.listbox2 = Listbox(self, width=10, height=ListHeight, activestyle="none", bd=2, relief=GROOVE,
                                selectbackground="#960000")
        self.listbox2.grid(in_=StatBox, row=1, column=1)
        self.listbox3 = Listbox(self, width=10, height=ListHeight, activestyle="none", bd=2, relief=GROOVE,
                                selectbackground="#960000")
        self.listbox3.grid(in_=StatBox, row=1, column=2)
        self.listbox4 = Listbox(self, width=10, height=ListHeight, activestyle="none", bd=2, relief=GROOVE,
                                selectbackground="#960000")
        self.listbox4.grid(in_=StatBox, row=1, column=3)
        # scrollbar
        self.scrollbar = Scrollbar(self, orient=VERTICAL, command=self.OnVsb)
        self.scrollbar.grid(in_=StatBox, row=1, column=4,  sticky=N + S)
        self.listbox1.configure(yscrollcommand=self.scrollbar.set)
        self.listbox2.configure(yscrollcommand=self.scrollbar.set)
        self.listbox3.configure(yscrollcommand=self.scrollbar.set)
        self.listbox4.configure(yscrollcommand=self.scrollbar.set)
        # call function to fill boxes - default: most correctly answered comes first
        self.fill_up_boxes(self.listbox1, self.listbox2, self.listbox3, self.listbox4, "most", QuestionStats)

        # binding - up & down
        self.listbox1.bind('<Up>', lambda event: self.scroll_listboxes(-1))
        self.listbox2.bind('<Up>', lambda event: self.scroll_listboxes(-1))
        self.listbox3.bind('<Up>', lambda event: self.scroll_listboxes(-1))
        self.listbox4.bind('<Up>', lambda event: self.scroll_listboxes(-1))
        self.listbox1.bind('<Down>', lambda event: self.scroll_listboxes(1))
        self.listbox2.bind('<Down>', lambda event: self.scroll_listboxes(1))
        self.listbox3.bind('<Down>', lambda event: self.scroll_listboxes(1))
        self.listbox4.bind('<Down>', lambda event: self.scroll_listboxes(1))
        # binding - mouse
        self.listbox1.bind("<MouseWheel>", self.OnMouseWheel)
        self.listbox2.bind("<MouseWheel>", self.OnMouseWheel)
        self.listbox3.bind("<MouseWheel>", self.OnMouseWheel)
        self.listbox4.bind("<MouseWheel>", self.OnMouseWheel)

        # buttons
        ButtonLabel = Label(self, text="List questions by the following criteria:", background="#fff",
                            font=('Georgia', 10, 'bold'))
        ButtonLabel.grid(in_=BigFrame, row=2)
        ButtonBox = Frame(self, background="#fff")
        ButtonBox.grid(in_=BigFrame, row=3, pady=5)
        MostButton = Button(self, text="Most correct", width=buttonWidth, background="#000",
                            command=lambda: self.fill_up_boxes(self.listbox1, self.listbox2, self.listbox3,
                                                               self.listbox4, "most", QuestionStats),
                            foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        MostButton.grid(in_=ButtonBox, row=0, column=0, padx=buttonPadx)
        LeastButton = Button(self, text="Least correct", width=buttonWidth, background="#000",
                             command=lambda: self.fill_up_boxes(self.listbox1, self.listbox2, self.listbox3,
                                                                self.listbox4, "least", QuestionStats),
                             foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        LeastButton.grid(in_=ButtonBox, row=0, column=1, padx=buttonPadx)
        NotButton = Button(self, text="Not answered", width=buttonWidth, background="#000", foreground="#fff",
                           command=lambda: self.fill_up_boxes(self.listbox1, self.listbox2, self.listbox3,
                                                              self.listbox4, "not", QuestionStats),
                           relief=FLAT, activebackground="#000", activeforeground="#fff")
        NotButton.grid(in_=ButtonBox, row=0, column=2, padx=buttonPadx)

    def fill_up_boxes(self, box1, box2, box3, box4, listtype, QuestionStats):
        box1.delete(0, END)
        box2.delete(0, END)
        box3.delete(0, END)
        box4.delete(0, END)
        if listtype == "most":
            print(listtype)
            l = []
            QuestionStats = sorted(QuestionStats, key=itemgetter(2))
            for i in QuestionStats:
                l.insert(0, i)
            QuestionStats = l
            # QuestionStats = order from most times correctly answered to least times correctly answered, zero times asked should not be included
        elif listtype == "least":
            print(listtype)
            QuestionStats = sorted(QuestionStats, key=itemgetter(2))
            # QuestionStats = order from least times correctly answered to most times correctly answered, zero times asked should not be included
        elif listtype == "not":
            print(listtype)
            l = []
            QuestionStats = sorted(QuestionStats, key=itemgetter(3))
            for i in QuestionStats:
                l.insert(0, i)
            QuestionStats = l
            # QuestionStats = order from most times not answered to least times not answered, zero times asked should not be included
        for n in range(0, len(QuestionStats)):
            box1.insert(END, QuestionStats[n][0])
            box2.insert(END, " " * (10 - len(str(QuestionStats[n][1]))) + str(QuestionStats[n][1]))
            corrincorr = "{:.2f}%".format(QuestionStats[n][2])
            box3.insert(END, " " * (10 - len(corrincorr)) + corrincorr)
            aband = "{:.2f}%".format(QuestionStats[n][3])
            box4.insert(END, " " * (10 - len(aband)) + aband)


    # mouse
    def OnMouseWheel(self, event):
        if event.num == 5 or event.delta == -120:
            yFactor = 1
        else:
            yFactor = -1
        self.listbox1.yview("scroll", yFactor, "units")
        self.listbox2.yview("scroll", yFactor, "units")
        self.listbox3.yview("scroll", yFactor, "units")
        self.listbox4.yview("scroll", yFactor, "units")
        return "break"

    # scrollbar    
    def OnVsb(self, *args):
        self.listbox1.yview(*args)
        self.listbox2.yview(*args)
        self.listbox3.yview(*args)
        self.listbox4.yview(*args)

    # up & down
    def scroll_listboxes(self, yFactor):
        self.listbox1.yview_scroll(yFactor, "units")
        self.listbox2.yview_scroll(yFactor, "units")
        self.listbox3.yview_scroll(yFactor, "units")
        self.listbox4.yview_scroll(yFactor, "units")

    def clear_sel(self):
        self.listbox1.selection_clear(0, END)
        self.listbox2.selection_clear(0, END)
        self.listbox3.selection_clear(0, END)
        self.listbox4.selection_clear(0, END)
