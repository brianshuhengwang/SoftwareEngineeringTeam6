from tkinter import *
from engageteamInterface import popup_chooset
from database import sqlQuestion
from database import sqlTopic
from engageteamInterface import popup_emptytopic

padY = 10
buttonWidth = 8
buttonPadx = 5
quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()

class ModDelTopic(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.initialModDelTopic()

    def initialModDelTopic(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)

        # Topics
        TopicLabel = Label(self, text="Topics:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        TopicLabel.grid(in_=BigFrame, row=0, sticky=W)
        TopicBox = Listbox(self, selectmode=BROWSE, activestyle="none", height=6, width=50, bd=2, relief=GROOVE, selectbackground="#960000")
        Scroll = Scrollbar(self, command=TopicBox.yview)
        Scroll.configure(background="#000", activebackground="#000", troughcolor="#fff")
        TopicBox.configure(yscrollcommand=Scroll.set)
        TopicBox.grid(in_=BigFrame, row=1)
        Scroll.grid(in_=BigFrame, row=1, column=1, sticky=N+S)
        global TopicList # do not touch this line!
        TopicList = topic.select_all()
        for item in TopicList:
            item = item[1]
            TopicBox.insert(END, item)

        # Buttons
        ButtonBox1 = Frame(self, pady=padY+3, background="#fff")
        ButtonBox1.grid(in_=BigFrame, row=2)
        ModButton = Button(self, text="Modify", width=buttonWidth, command=lambda: self.modTopic(TopicBox, BigFrame), background="#000",
                              foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        ModButton.grid(in_=ButtonBox1, row=0, column=0, padx=buttonPadx)
        DelButton = Button(self, text="Delete", width=buttonWidth, command=lambda: self.delTopic(TopicBox, BigFrame), background="#000",
                               foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        DelButton.grid(in_=ButtonBox1, row=0, column=1, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command= self.close_window, background="#000", foreground="#fff",
                              relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox1, row=0, column=2, padx=buttonPadx)

    def close_window(self):
        self.master.destroy()

    def modTopic(self, TopicBox, BigFrame):
        ChosenT = TopicBox.curselection()
        if len(ChosenT)==0:
            self.pop_up_warning("chosen")
            return
        TopicName = TopicList[ChosenT[0]]
        topic_id = TopicList[ChosenT[0]][0] 
        print(TopicName)
        
        BigFrame.grid_forget()
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)

        # Topic
        TopicLabel = Label(self, text="Topic name:", font=('MS', 12, 'bold'), pady=10, background="#fff")
        TopicLabel.grid(in_=BigFrame, row=0, sticky=W)
        T = StringVar()
        T.set(TopicName[1])
        TopicBox = Entry(self, textvariable=T, width=40, font=(10), bd=2, relief=GROOVE)
        TopicBox.grid(in_=BigFrame, row=1)

        # Buttons
        ButtonBox = Frame(self, background="#fff")
        ButtonBox.grid(in_=BigFrame, pady=13)
        SaveButton = Button(self, text="Save", width=buttonWidth, command=lambda: self.saveTopic(topic_id, T, BigFrame), background="#000",
                            foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        SaveButton.grid(in_=ButtonBox, row=0, column=0, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command=lambda: self.displayModDelT(BigFrame), background="#000",
                              foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox, row=0, column=1, padx=buttonPadx)
        

    def displayModDelT(self, BigFrame):
        BigFrame.grid_forget()
        self.initialModDelTopic()

    def saveTopic(self, topic_id, T, BigFrame):
        if T.get()=="":
            self.pop_up_warning("empty")
            return
        topic.modify_by_id(topic_id,T.get())
        self.displayModDelT(BigFrame)
     

    def delTopic(self, TopicBox, BigFrame):
        ChosenT = TopicBox.curselection()
        if len(ChosenT)==0:
            self.pop_up_warning("chosen")
            return
        index = ChosenT[0] # getting the integer from the tuple
        TopicName = TopicList[index] # getting the topicname itself
        topic.delete_topic(TopicName[0])
        ## ask user if they are sure about deleting
        ## if cancel
            ## return
        ## delete topic from the database
        ## pop-up to tell the user the topic was deleted
        del TopicList[index]
        TopicBox.delete(0, END)
        for item in TopicList:
            TopicBox.insert(END, item[1])

    def pop_up_warning(self, warningType):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Warning")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.configure(background="#fff")
        self.newWindow.minsize(width=480, height=150)
        self.newWindow.grab_set()
        self.newWindow.focus()
        if warningType=="chosen":
            self.app = popup_chooset.chooseTopic(self.newWindow)
        elif warningType=="empty":
            self.app = popup_emptytopic.emptyField(self.newWindow)
        

