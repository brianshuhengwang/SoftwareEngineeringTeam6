from tkinter import *

import os, sys, inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from engageteamInterface import type_in_questions
from engageteamInterface import moddel_questions
from engageteamInterface import add_topic
from engageteamInterface import moddel_topics
from engageteamInterface import alltime_stats
from engageteamInterface import reset_window

padX = 10  # padding for the menu boxes
padY = 10  # padding for the menu boxes
buttonWidth = 22
buttonPadding = 2


class AdminMenu(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.displayMainMenu()

    def displayMainMenu(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)

        # Manage questions
        ManageQBox = Frame(self, background="#fff")
        ManageQBox.grid(in_=BigFrame, row=0, column=0, padx=padX, pady=padY, sticky=N, columnspan=2)
        ManageQLabel = Label(self, text="Manage questions:", font=('MS', 12, 'bold'), background="#fff")
        ManageQLabel.grid(in_=ManageQBox, row=0)
        TypeQButton = Button(self, text="Type in questions", width=buttonWidth, command=self.typein_window,
                             background="#000", foreground="#fff",
                             activebackground="#000", activeforeground="#fff", relief=FLAT)
        TypeQButton.grid(in_=ManageQBox, row=1, pady=buttonPadding)
        ModDelQButton = Button(self, text="Modify / delete questions", width=buttonWidth, command=self.moddelq_window,
                               background="#000", foreground="#fff",
                               activebackground="#000", activeforeground="#fff", relief=FLAT)
        ModDelQButton.grid(in_=ManageQBox, row=2, pady=buttonPadding)

        # Manage topics:
        ManageTBox = Frame(self, background="#fff")
        ManageTBox.grid(in_=BigFrame, row=1, column=0, padx=padX, pady=padY, columnspan=2)
        ManageTLabel = Label(self, text="Manage topics:", font=('MS', 12, 'bold'), background="#fff")
        ManageTLabel.grid(in_=ManageTBox, row=0)
        AddTButton = Button(self, text="Add new topics", width=buttonWidth, command=self.addtopic_window,
                            background="#000", foreground="#fff",
                            activebackground="#000", activeforeground="#fff", relief=FLAT)
        AddTButton.grid(in_=ManageTBox, row=1, pady=buttonPadding)
        ModDelTButton = Button(self, text="Modify / delete topics", width=buttonWidth, command=self.moddelt_window,
                               background="#000", foreground="#fff",
                               activebackground="#000", activeforeground="#fff", relief=FLAT)
        ModDelTButton.grid(in_=ManageTBox, row=2, pady=buttonPadding)

        # Statistics
        StatisticsBox = Frame(self, background="#fff")
        StatisticsBox.grid(in_=BigFrame, row=0, column=2, padx=padX, pady=padY, sticky=N, columnspan=2)
        StatisticsLabel = Label(self, text="Statistics:", font=('MS', 12, 'bold'), background="#fff")
        StatisticsLabel.grid(in_=StatisticsBox, row=0)
        AlltimeButton = Button(self, text="View all-time statistics", width=buttonWidth, command=self.alltime_window,
                               background="#000", foreground="#fff",
                               activebackground="#000", activeforeground="#fff", relief=FLAT)
        AlltimeButton.grid(in_=StatisticsBox, row=1, pady=buttonPadding)
        BrowseSButton = Button(self, text="Browse by sessions", width=buttonWidth, background="#000", foreground="#fff",
                               activebackground="#000", activeforeground="#fff", relief=FLAT)
        BrowseSButton.grid(in_=StatisticsBox, row=2, pady=buttonPadding)

        # Manage Sessions
        ManageSBox = Frame(self, background="#fff")
        ManageSBox.grid(in_=BigFrame, row=1, column=2, padx=padX, pady=padY, sticky=N, columnspan=2)
        ManageSLabel = Label(self, text="Manage sessions:", font=('MS', 12, 'bold'), background="#fff")
        ManageSLabel.grid(in_=ManageSBox, row=0)
        NewSButton = Button(self, text="Create a new session", width=buttonWidth, background="#000", foreground="#fff",
                            activebackground="#000", activeforeground="#fff", relief=FLAT)
        NewSButton.grid(in_=ManageSBox, row=1, pady=buttonPadding)
        ContSButton = Button(self, text="Continue last session", width=buttonWidth, background="#000",
                             foreground="#fff",
                             activebackground="#000", activeforeground="#fff", relief=FLAT)
        ContSButton.grid(in_=ManageSBox, row=2, pady=buttonPadding)
        DelSButton = Button(self, text="Delete sessions", width=buttonWidth, background="#000", foreground="#fff",
                            activebackground="#000", activeforeground="#fff", relief=FLAT)
        DelSButton.grid(in_=ManageSBox, row=3, pady=buttonPadding)

        # Reset
        ResetBox = Frame(self, background="#fff")
        ResetBox.grid(in_=BigFrame, row=2, column=1, padx=padX, pady=padY, sticky=N, columnspan=2)
        ResetLabel = Label(self, text="Reset statistics:", font=('MS', 12, 'bold'), background="#fff")
        ResetLabel.grid(in_=ResetBox, row=0)
        ResetButton = Button(self, text="Reset", width=buttonWidth, command=self.reset_window, background="#000",
                             foreground="#fff",
                             activebackground="#000", activeforeground="#fff", relief=FLAT)
        ResetButton.grid(in_=ResetBox, row=1)

    # new window when "type in questions" gets clicked
    def typein_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Add new questions")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = type_in_questions.TypeQuestions(self.newWindow)

    # new window when "modify / delete questions" gets clicked
    def moddelq_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Manage questions")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = moddel_questions.ModDelQues(self.newWindow)

    # new window when "add new topics" gets clicked
    def addtopic_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Add new topics")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = add_topic.AddTopic(self.newWindow)

    # new window when "modify / delete topics" gets clicked
    def moddelt_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Manage topics")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = moddel_topics.ModDelTopic(self.newWindow)

    # new window when "view all-time statistics" gets clicked
    def alltime_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("All-time statistics")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = alltime_stats.stats(self.newWindow)

    # new window when "reset" gets clicked
    def reset_window(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Reset")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.focus()
        self.app = reset_window.resetAll(self.newWindow)


root = Tk()
root.title("Manage quiz")
root.configure(background="#fff")
root.resizable(width=False, height=False)
app = AdminMenu(root)
root.mainloop()
