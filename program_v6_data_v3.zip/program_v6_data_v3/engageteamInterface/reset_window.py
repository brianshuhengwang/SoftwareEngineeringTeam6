from tkinter import *


class resetAll(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.displayReset()

    def displayReset(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=30, pady=15)

        img = PhotoImage(file="warningsign.gif")
        warningSign = Label(self, image=img, background="#fff")
        warningSign.photo = img
        warningSign.grid(in_=BigFrame, row=0)

        BlablaBox = Frame(self, background="#fff")
        BlablaBox.grid(in_=BigFrame, row=0, column=1, padx=30)
        Bla1 = Label(self, text="All sessions and statistical data will be deleted.", font=('MS', 14),
                     background="#fff")
        Bla1.grid(in_=BlablaBox, row=0)
        Bla2 = Label(self, text="Are you sure you want to continue?", font=('MS', 14), background="#fff")
        Bla2.grid(in_=BlablaBox, row=1)
        ButtonBox = Frame(self, background="#fff")
        ButtonBox.grid(in_=BlablaBox, row=2, pady=10)
        OKbutton = Button(self, text="Yes", width=8, command=self.reset_stats, background="#000", foreground="#fff",
                          activebackground="#000", activeforeground="#fff", relief=FLAT)
        OKbutton.grid(in_=ButtonBox, row=0, padx=5)
        CancelButton = Button(self, text="Cancel", width=8, command=self.close_window, background="#000",
                              foreground="#fff",
                              activebackground="#000", activeforeground="#fff", relief=FLAT)
        CancelButton.grid(in_=ButtonBox, row=0, column=1, padx=5)

    def close_window(self):
        self.master.destroy()

    def reset_stats(self):
        # delete all sessions from session database
        # zero out all statistical data in question database
        print("deleted")
        self.close_window()
