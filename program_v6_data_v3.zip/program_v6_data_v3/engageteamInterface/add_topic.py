from tkinter import *
from database import sqlQuestion
from database import sqlTopic
from engageteamInterface import popup_emptytopic

buttonWidth = 8
buttonPadx = 5
quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()

class AddTopic(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.displayAddTopic()

    def displayAddTopic(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)

        # Topic
        TopicLabel = Label(self, text="Topic name:", font=('MS', 12, 'bold'), pady=10, background="#fff")
        TopicLabel.grid(in_=BigFrame, row=0, sticky=W)
        T = StringVar()
        TopicBox = Entry(self, textvariable=T, width=40, font=(10), bd=2, relief=GROOVE)
        TopicBox.grid(in_=BigFrame, row=1)

        # Buttons
        ButtonBox = Frame(self, background="#fff")
        ButtonBox.grid(in_=BigFrame, pady=13)
        SaveButton = Button(self, text="Save", width=buttonWidth, command=lambda: self.saveTopic(T), background="#000",
                            foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        SaveButton.grid(in_=ButtonBox, row=0, column=0, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command= self.close_window, background="#000",
                              foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox, row=0, column=1, padx=buttonPadx)

    def close_window(self):
        self.master.destroy()

    def saveTopic(self, T):
        if T.get()=="":
            self.pop_up_warning()
            return
        topic.add_topic(T.get())
        self.displayAddTopic() # clears field

    def pop_up_warning(self):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Warning")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.configure(background="#fff")
        self.newWindow.minsize(width=500, height=150)
        self.newWindow.grab_set()
        self.newWindow.focus()
        self.app = popup_emptytopic.emptyField(self.newWindow)

