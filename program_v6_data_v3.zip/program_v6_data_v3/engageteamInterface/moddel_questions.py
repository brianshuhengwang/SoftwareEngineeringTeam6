from tkinter import *
from engageteamInterface import popup_chooseq
from engageteamInterface import popup_search
from engageteamInterface import popup_emptys
from database import sqlQuestion
from database import sqlTopic

buttonWidth = 8
buttonPadx = 5
entryWidth = 33
padY = 10
quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()


class ModDelQues(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid()
        self.configure(background="#fff")
        self.initialModDelQues()

    def initialModDelQues(self):
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=15, pady=10)
        LeftSide = Frame(self, background="#fff")
        LeftSide.grid(in_=BigFrame, row=0, padx=10, sticky=N)
        RightSide = Frame(self, background="#fff")
        RightSide.grid(in_=BigFrame, row=0, column=1, padx=10, sticky=N)

        # Search term
        TermLabel = Label(self, text="Search term:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        TermLabel.grid(in_=LeftSide, row=0, sticky=W)
        T = StringVar()
        TermBox = Entry(self, textvariable=T, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        TermBox.grid(in_=LeftSide, row=1)

        # Topics
        TopicLabel = Label(self, text="List questions by topics:", font=('MS', 12, 'bold'), pady=padY,
                           background="#fff")
        TopicLabel.grid(in_=LeftSide, row=2, sticky=W)
        TopicBox = Listbox(self, selectmode=EXTENDED, activestyle="none", height=6, width=50, bd=2, relief=GROOVE,
                           selectbackground="#960000")
        Scroll1 = Scrollbar(self, command=TopicBox.yview)
        Scroll1.configure(background="#000", activebackground="#000", troughcolor="#fff")
        TopicBox.configure(yscrollcommand=Scroll1.set)
        TopicBox.grid(in_=LeftSide, row=3)
        Scroll1.grid(in_=LeftSide, row=3, column=1, sticky=N + S)
        global TopicList  # do not touch this line
        TopicList = topic.select_all()
        for item in TopicList:
            item = item[1]
            TopicBox.insert(END, item)

        # Buttons - group 1
        ButtonBox1 = Frame(self, pady=padY + 3, background="#fff")
        ButtonBox1.grid(in_=LeftSide, row=4)
        SearchButton = Button(self, text="Search", width=buttonWidth,
                              command=lambda: self.performSearch(T, TopicBox, QuestionBox), background="#000",
                              foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        SearchButton.grid(in_=ButtonBox1, row=0, column=0, padx=buttonPadx)
        ListAllButton = Button(self, text="List all", width=buttonWidth, command=lambda: self.allQuestions(QuestionBox),
                               background="#000",
                               foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        ListAllButton.grid(in_=ButtonBox1, row=0, column=1, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command=self.close_window, background="#000",
                              foreground="#fff",
                              relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox1, row=0, column=2, padx=buttonPadx)

        # Questions
        QuestionLabel = Label(self, text="Questions:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        QuestionLabel.grid(in_=RightSide, row=0, sticky=W)
        QuestionBox = Listbox(self, selectmode=BROWSE, activestyle="none", height=6, width=50, bd=2, relief=GROOVE,
                              selectbackground="#960000")
        Scroll2 = Scrollbar(self, command=QuestionBox.yview)
        Scroll2.configure(background="#000", activebackground="#000", troughcolor="#fff")
        QuestionBox.configure(yscrollcommand=Scroll2.set)
        QuestionBox.grid(in_=RightSide, row=1)
        Scroll2.grid(in_=RightSide, row=1, column=1, sticky=N + S)

        # Buttons - group 2
        ButtonBox2 = Frame(self, pady=padY + 3, background="#fff")
        ButtonBox2.grid(in_=RightSide, row=3)
        ModButton = Button(self, text="Modify", width=buttonWidth, command=lambda: self.modifyQ(QuestionBox, BigFrame),
                           background="#000", foreground="#fff",
                           relief=FLAT, activebackground="#000", activeforeground="#fff")
        ModButton.grid(in_=ButtonBox2, row=0, column=0, padx=buttonPadx)
        DelButton = Button(self, text="Delete", width=buttonWidth, command=lambda: self.deleteQ(QuestionBox),
                           background="#000", foreground="#fff",
                           relief=FLAT, activebackground="#000", activeforeground="#fff")
        DelButton.grid(in_=ButtonBox2, row=0, column=1, padx=buttonPadx)

    def close_window(self):
        self.master.destroy()

    def performSearch(self, T, TB, QuestionBox):
        Term = T.get()
        TopicBox = TB.curselection()
        ChosenTopics = []  # list of strings where strings are the names of the chosen topics
        for item in TopicBox:
            ChosenTopics.append(TopicList[item])
        global QuestionList  # don't touch this line!
        QuestionBox.delete(0, END)
        if Term == "":
            if len(TopicBox) == 0:
                self.pop_up_warning("search")
                return
            else:
                for item in TopicBox:
                    print(TopicList[item][0])
                    QuestionList = quiz.select_by_topic_id(TopicList[item][0])
        else:
            QuestionList = quiz.select_by_question(Term)
        for item in QuestionList:
            QuestionBox.insert(END, item[1])

    def allQuestions(self, QuestionBox):
        global QuestionList  # don't touch this line!
        QuestionList = quiz.select_all()
        QuestionBox.delete(0, END)
        for item in QuestionList:
            QuestionBox.insert(END, item[1])

    def deleteQ(self, QuestionBox):
        ChosenQ = QuestionBox.curselection()
        if len(ChosenQ) == 0:
            self.pop_up_warning("question")
            return
        index = ChosenQ[0]  # taking out the integer from the tuple
        TheQuestion = QuestionList[index]
        ## ask user if they are sure about deleting the question
        ## if cancel
        ## return
        ## delete question from the database
        del QuestionList[index]  # then we remove it from the list as well
        QuestionBox.delete(0, END)  # and update the list displayed in the box
        for item in QuestionList:
            QuestionBox.insert(END, item)

    def modifyQ(self, QuestionBox, BigFrame):
        ChosenQ = QuestionBox.curselection()
        if len(ChosenQ) == 0:
            self.pop_up_warning("question")
            return
        index = ChosenQ[0]
        TheQuestion = QuestionList[index]

        BigFrame.grid_forget()
        BigFrame = Frame(self, background="#fff")
        BigFrame.grid(row=0, column=0, padx=25, pady=10)

        # Question
        quiz_id = TheQuestion[0]
        MQuestionLabel = Label(self, text="Question:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        MQuestionLabel.grid(in_=BigFrame, row=0, sticky=W)
        MQ = StringVar()
        MQ.set(TheQuestion[1])
        MQuestionBox = Entry(self, textvariable=MQ, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        MQuestionBox.grid(in_=BigFrame, row=1)

        # Correct Answer
        CorrectLabel = Label(self, text="Correct answer:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        CorrectLabel.grid(in_=BigFrame, row=2, sticky=W)
        C = StringVar()
        C.set(TheQuestion[2])
        CorrectBox = Entry(self, textvariable=C, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        CorrectBox.grid(in_=BigFrame, row=3)

        # False Answer 1
        False1Label = Label(self, text="False answer 1:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        False1Label.grid(in_=BigFrame, row=4, sticky=W)
        F1 = StringVar()
        F1.set(TheQuestion[3])
        False1Box = Entry(self, textvariable=F1, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        False1Box.grid(in_=BigFrame, row=5)

        # False Answer 2
        False2Label = Label(self, text="False answer 2:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        False2Label.grid(in_=BigFrame, row=6, sticky=W)
        F2 = StringVar()
        F2.set(TheQuestion[4])
        False2Box = Entry(self, textvariable=F2, width=entryWidth, font=(10), bd=2, relief=GROOVE)
        False2Box.grid(in_=BigFrame, row=7)

        # Topics
        MTopicLabel = Label(self, text="Topics:", font=('MS', 12, 'bold'), pady=padY, background="#fff")
        MTopicLabel.grid(in_=BigFrame, row=8, sticky=W)
        BoxAndScroll = Frame(self)
        BoxAndScroll.grid(in_=BigFrame, row=9)
        MTopicBox = Listbox(self, selectmode=EXTENDED, activestyle="none", height=6, width=50, bd=2, relief=GROOVE,
                            selectbackground="#960000")
        Scroll = Scrollbar(self, command=MTopicBox.yview)
        Scroll.configure(background="#000", activebackground="#000", troughcolor="#fff")
        MTopicBox.configure(yscrollcommand=Scroll.set)
        MTopicBox.grid(in_=BoxAndScroll, row=0)
        Scroll.grid(in_=BoxAndScroll, row=0, column=1, sticky=N + S)
        global TopicList  # don't touch this line
        TopicList = topic.select_all()
        for item in TopicList:
            item = item[1]
            MTopicBox.insert(END, item)

        # Buttons
        ButtonBox = Frame(self, pady=padY + 3, background="#fff")
        ButtonBox.grid(in_=BigFrame, row=10)
        SaveButton = Button(self, text="Save", width=buttonWidth,
                            command=lambda: self.SaveQuestion(quiz_id, MQ, C, F1, F2, MTopicBox, BigFrame),
                            background="#000",
                            foreground="#fff", relief=FLAT, activebackground="#000", activeforeground="#fff")
        SaveButton.grid(in_=ButtonBox, row=0, column=0, padx=buttonPadx)
        CancelButton = Button(self, text="Cancel", width=buttonWidth, command=self.close_window, background="#000",
                              foreground="#fff",
                              relief=FLAT, activebackground="#000", activeforeground="#fff")
        CancelButton.grid(in_=ButtonBox, row=0, column=1, padx=buttonPadx)

    def SaveQuestion(self, qus_id, Q, C, F1, F2, TB, BigFrame):
        qus_body = Q.get()
        correct_ans = C.get()
        false_ans1 = F1.get()
        false_ans2 = F2.get()
        if (qus_body == "") or (correct_ans == "") or (false_ans1 == "") or (false_ans2 == ""):
            self.pop_up_warning("empty fields")
            return
        index = TB.curselection()
        topic_select = []
        for item in index:
            topic_select.append(TopicList[item][0])
        qus_topic = str(topic_select)
        qus_topic = qus_topic.strip("[")
        qus_topic = qus_topic.strip("]")
        quiz.modify_by_id(str(qus_id), qus_body, correct_ans, false_ans1, false_ans2, qus_topic)
        self.displayModDelQ(BigFrame)

    def displayModDelQ(self, BigFrame):
        BigFrame.grid_forget()
        self.initialModDelQues()

    def pop_up_warning(self, warningType):
        self.newWindow = Toplevel(self.master)
        self.newWindow.title("Warning")
        self.newWindow.resizable(width=False, height=False)
        self.newWindow.configure(background="#fff")
        self.newWindow.minsize(width=500, height=150)
        self.newWindow.grab_set()
        self.newWindow.focus()
        if warningType == "question":
            self.app = popup_chooseq.chooseQuestion(self.newWindow)
        elif warningType == "search":
            self.app = popup_search.searchWarning(self.newWindow)
        elif warningType == "empty fields":
            self.app = popup_emptys.emptyFields(self.newWindow)
