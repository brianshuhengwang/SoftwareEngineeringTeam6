from database import sqlQuestion
from database import sqlTopic
import random

quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()


class Function:
    def get_ten_question_all(self):
        allQus = quiz.select_all()
        lenq = len(allQus)
        index = []
        tenQusIndex = []
        tenqus = []
        for i in range(0, lenq):
            index.append(i)
        d = 0
        while d < 10:
            x = random.choice(index)
            index.remove(x)
            tenQusIndex.append(x)
            d += 1
        for item in tenQusIndex:
            tenqus.append(allQus[item])
        return tenqus

    def get_ten_question_topic(self, topic_id):
        allQus = quiz.select_by_topic_id(topic_id)
        lenq = len(allQus)
        index = []
        tenQusIndex = []
        tenqus = []
        for i in range(0, lenq):
            index.append(i)
        d = 0
        while d < 10:
            x = random.choice(index)
            index.remove(x)
            tenQusIndex.append(x)
            d += 1
        for item in tenQusIndex:
            tenqus.append(allQus[item])
        return tenqus

    def question_stat(self):
        all_stat = []
        question = quiz.select_all()
        for qus in range(0, len(question) - 1):
            qus_body = question[qus][1]
            ans_time = question[qus][5] + question[qus][6] + question[qus][7]
            if ans_time == 0:
                correct = "not answered"
                ans_skip = "not answered"
            else:
                correct = (question[qus][5] / ans_time) * 100
                ans_skip = (question[qus][7] / ans_time) * 100
            stat = [qus_body, ans_time, correct, ans_skip]
            all_stat.append(stat)
        return all_stat


