import sqlite3

import os, sys, inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)


# this package is used for question table
# delete by id, modify by id, select by id, select all complete


class SqlQuestion:
    def connect(self):
        # connect method to connect database
        db = sqlite3.connect("../database/questiondb")
        return db

    def select_all(self):
        # show all of the content in database
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM question")
        re = cursor.fetchall()
        return re

    def select_by_id(self, qus_id):
        # show the question by qus_id
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select * from question where qus_id={}".format(qus_id))
        re = cursor.fetchall()
        cursor.close()
        return re

    def modify_by_id(self, qus_id, qus_body, qus_ans_correct, qus_ans_false1, qus_ans_false2, qus_topic):
        # modify the question by qus_id
        db = self.connect()
        cursor = db.cursor()
        cursor.execute(
            '''UPDATE question SET qus_body=?,qus_ans_correct=?,qus_ans_false1=?,qus_ans_false2=?, qus_topic=? WHERE qus_id=?''',
            [qus_body, qus_ans_correct, qus_ans_false1, qus_ans_false2, qus_topic, qus_id])
        db.commit()
        cursor.close()

    def modify_correct(self, qus_id):
        ans_correct = self.select_by_id(qus_id)[0][5]
        newcorrect = ans_correct + 1
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("UPDATE question SET ans_correct=? WHERE qus_id=?", [newcorrect, qus_id])
        db.commit()
        cursor.close()

    def modify_false(self, qus_id):
        ans_false = self.select_by_id(qus_id)[0][6]
        new_false = ans_false + 1
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("UPDATE question SET ans_wrong=? WHERE qus_id=?", [new_false, qus_id])
        db.commit()
        cursor.close()

    def modify_skip(self, qus_id):
        ans_skip = self.select_by_id(qus_id)[0][7]
        new_skip = ans_skip + 1
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("UPDATE question SET ans_skip=? WHERE qus_id=?", [new_skip, qus_id])
        db.commit()
        cursor.close()

    def get_id(self):
        # method to get the qus_id of the last question and return the new id which the last question id add 1
        db = self.connect()
        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM question")
            select = cursor.fetchall()
            qus_id = select[-1][0] + 1
        except IndexError:
            qus_id = 1
        return qus_id

    def add_question(self, qus_body, qus_ans_correct, qus_ans_false1, qus_ans_false2, qus_topic, ans_correct=0,
                     ans_wrong=0, ans_skip=0):
        # add new question in question table
        qus_id = self.get_id()
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("INSERT INTO question VALUES (?,?,?,?,?,?,?,?,?)",
                       [str(qus_id), qus_body, qus_ans_correct, qus_ans_false1, qus_ans_false2,
                        str(ans_correct),
                        str(ans_wrong), str(ans_skip), qus_topic])
        db.commit()
        cursor.close()

    def delete_question(self, qus_id):
        # delete select question which id has been selected.
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("delete from question where qus_id={}".format(qus_id))
        db.commit()
        cursor.close()

    def select_by_topic_id(self, topic_id):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select * from question where qus_topic LIKE '%{}%'".format(topic_id))
        re = cursor.fetchall()
        return re

    def select_by_question(self, question_body):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select * from question where qus_body LIKE '%{}%'".format(question_body))
        re = cursor.fetchall()
        return re
