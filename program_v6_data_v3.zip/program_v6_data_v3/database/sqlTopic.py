import sqlite3

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)


class SqlTopic:
    def connect(self):
        db = sqlite3.connect("../database/questiondb")
        return db

    def select_all(self):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM topic")
        re = cursor.fetchall()
        return re

    def select_by_id(self, topic_id):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("select topic_name from topic where topic_id={}".format(topic_id))
        re = cursor.fetchall()
        cursor.close()
        return re

    def modify_by_id(self, topic_id, topic_name):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("UPDATE topic SET topic_name=? WHERE topic_id=?", [topic_name, topic_id])
        db.commit()
        cursor.close()

    def get_id(self):
        db = self.connect()
        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM topic")
            select = cursor.fetchall()
            topic_id = select[-1][0] + 1
        except IndexError:
            topic_id = 1
        return topic_id

    def add_topic(self, topic_name):
        topic_id = self.get_id()
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("INSERT INTO topic VALUES (?,?)", [str(topic_id), topic_name])
        db.commit()
        cursor.close()

    def delete_topic(self, topic_id):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("delete from topic where topic_id={}".format(topic_id))
        db.commit()
        cursor.close()

    def get_topic_id(self, topic_name):
        db = self.connect()
        cursor = db.cursor()
        cursor.execute("SELECT topic_id FROM topic WHERE topic_name=?", [topic_name])
        re = cursor.fetchall()
        return re
