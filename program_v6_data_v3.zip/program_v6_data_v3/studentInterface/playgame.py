from database import sqlTopic
from database import sqlQuestion
from database import func
from tkinter import *
import random

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)

quiz = sqlQuestion.SqlQuestion()
topic = sqlTopic.SqlTopic()
sql = func.Function()
ten_qus = sql.get_ten_question_all()


class QuizGame(Frame):
    def __init__(self, master):
        Frame.__init__(self, master=master, bg='#eeeeee')
        self.place(bordermode=OUTSIDE, relheight=1, relwidth=1)
        self.font = ('Verdana', '14', 'bold')
        self.currentFrame = None
        self.stringVar = StringVar(master)
        self.game_start()
        self.replaceFrame(self.start)
        self.clear_response()

    def game_start(self):
        # Frames
        self.start = Frame(self, bg='#dddddd')
        self.q1f = Frame(self, bg='#dddddd')
        self.q2f = Frame(self, bg='#dddddd')
        self.q3f = Frame(self, bg='#dddddd')
        self.q4f = Frame(self, bg='#dddddd')
        self.q5f = Frame(self, bg='#dddddd')
        self.q6f = Frame(self, bg='#dddddd')
        self.q7f = Frame(self, bg='#dddddd')
        self.q8f = Frame(self, bg='#dddddd')
        self.q9f = Frame(self, bg='#dddddd')
        self.q10f = Frame(self, bg='#dddddd')

        # start object
        start_btn = Button(self.start, text="start quiz", command=lambda: self.replaceFrame(self.q1f))
        start_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.50, y=300, relx=0.30)

        # disply object

        # question 1
        q1y = self.place_answer()
        qus1lable = Label(self.q1f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="1: " + ten_qus[0][1])
        qus1lable.place(bordermode=OUTSIDE, height=20, relwidth=0.9, y=20, relx=0.1)
        self.qus1ans = IntVar()

        qus1ans1 = Radiobutton(self.q1f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[0][2],
                               variable=self.qus1ans, value=1)
        qus1ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q1y[0], relx=0.1)
        qus1ans2 = Radiobutton(self.q1f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[0][3],
                               variable=self.qus1ans, value=2)
        qus1ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q1y[1], relx=0.1)
        qus1ans3 = Radiobutton(self.q1f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[0][4],
                               variable=self.qus1ans, value=3)
        qus1ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q1y[2], relx=0.1)

        next_1_btn = Button(self.q1f, text="Next", command=lambda: self.replaceFrame(self.q2f))
        next_1_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 2
        q2y = self.place_answer()
        qus2Lable = Label(self.q2f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="2: " + ten_qus[1][1])
        qus2Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0)
        self.qus2ans = IntVar()
        qus2ans1 = Radiobutton(self.q2f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[1][2],
                               variable=self.qus2ans, value=1)
        qus2ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q2y[0], relx=0.1)
        qus2ans2 = Radiobutton(self.q2f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[1][3],
                               variable=self.qus2ans, value=2)
        qus2ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q2y[1], relx=0.1)
        qus2ans3 = Radiobutton(self.q2f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[1][4],
                               variable=self.qus2ans, value=3)
        qus2ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q2y[2], relx=0.1)

        pre_2_btn = Button(self.q2f, text="Previous", command=lambda: self.replaceFrame(self.q1f))
        pre_2_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_2_btn = Button(self.q2f, text="Next", command=lambda: self.replaceFrame(self.q3f))
        next_2_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 3
        q3y = self.place_answer()
        qus3Lable = Label(self.q3f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="3: " + ten_qus[2][1])
        qus3Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)

        self.qus3ans = IntVar()
        qus3ans1 = Radiobutton(self.q3f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[2][2],
                               variable=self.qus3ans, value=1)
        qus3ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q3y[0], relx=0.1)
        qus3ans2 = Radiobutton(self.q3f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[2][3],
                               variable=self.qus3ans, value=2)
        qus3ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q3y[1], relx=0.1)
        qus3ans3 = Radiobutton(self.q3f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[2][4],
                               variable=self.qus3ans, value=3)
        qus3ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q3y[2], relx=0.1)

        pre_3_btn = Button(self.q3f, text="Previous", command=lambda: self.replaceFrame(self.q2f))
        pre_3_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_3_btn = Button(self.q3f, text="Next", command=lambda: self.replaceFrame(self.q4f))
        next_3_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 4
        q4y = self.place_answer()
        qus4Lable = Label(self.q4f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="4: " + ten_qus[3][1])
        qus4Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus4ans = IntVar()
        qus4ans1 = Radiobutton(self.q4f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[3][2],
                               variable=self.qus4ans, value=1)
        qus4ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q4y[0], relx=0.1)
        qus4ans2 = Radiobutton(self.q4f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[3][3],
                               variable=self.qus4ans, value=2)
        qus4ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q4y[1], relx=0.1)
        qus4ans3 = Radiobutton(self.q4f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[3][4],
                               variable=self.qus4ans, value=3)
        qus4ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q4y[2], relx=0.1)

        pre_4_btn = Button(self.q4f, text="Previous", command=lambda: self.replaceFrame(self.q3f))
        pre_4_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_4_btn = Button(self.q4f, text="Next", command=lambda: self.replaceFrame(self.q5f))
        next_4_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 5
        q5y = self.place_answer()
        qus5Lable = Label(self.q5f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="5: " + ten_qus[4][1])
        qus5Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus5ans = IntVar()
        qus5ans1 = Radiobutton(self.q5f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[4][2],
                               variable=self.qus5ans, value=1)
        qus5ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q5y[0], relx=0.1)
        qus5ans2 = Radiobutton(self.q5f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[4][3],
                               variable=self.qus5ans, value=2)
        qus5ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q5y[1], relx=0.1)
        qus5ans3 = Radiobutton(self.q5f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[4][4],
                               variable=self.qus5ans, value=3)
        qus5ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q5y[2], relx=0.1)

        pre_2_btn = Button(self.q5f, text="Previous", command=lambda: self.replaceFrame(self.q4f))
        pre_2_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_5_btn = Button(self.q5f, text="Next", command=lambda: self.replaceFrame(self.q6f))
        next_5_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 6
        q6y = self.place_answer()
        qus6Lable = Label(self.q6f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="6: " + ten_qus[5][1])
        qus6Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus6ans = IntVar()
        qus6ans1 = Radiobutton(self.q6f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[5][2],
                               variable=self.qus6ans, value=1)
        qus6ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q6y[0], relx=0.1)
        qus6ans2 = Radiobutton(self.q6f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[5][3],
                               variable=self.qus6ans, value=2)
        qus6ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q6y[1], relx=0.1)
        qus6ans3 = Radiobutton(self.q6f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[5][4],
                               variable=self.qus6ans, value=3)
        qus6ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q6y[2], relx=0.1)

        pre_6_btn = Button(self.q6f, text="Previous", command=lambda: self.replaceFrame(self.q5f))
        pre_6_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_6_btn = Button(self.q6f, text="Next", command=lambda: self.replaceFrame(self.q7f))
        next_6_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 7
        q7y = self.place_answer()
        qus7Lable = Label(self.q7f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="7: " + ten_qus[6][1])
        qus7Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus7ans = IntVar()
        qus7ans1 = Radiobutton(self.q7f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[6][2],
                               variable=self.qus7ans, value=1)
        qus7ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q7y[0], relx=0.1)
        qus7ans2 = Radiobutton(self.q7f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[6][3],
                               variable=self.qus7ans, value=2)
        qus7ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q7y[1], relx=0.1)
        qus7ans3 = Radiobutton(self.q7f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[6][4],
                               variable=self.qus7ans, value=3)
        qus7ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q7y[2], relx=0.1)

        pre_7_btn = Button(self.q7f, text="Previous", command=lambda: self.replaceFrame(self.q6f))
        pre_7_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_7_btn = Button(self.q7f, text="Next", command=lambda: self.replaceFrame(self.q8f))
        next_7_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 8
        q8y = self.place_answer()
        qus8Lable = Label(self.q8f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="8: " + ten_qus[7][1])
        qus8Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus8ans = IntVar()
        qus8ans1 = Radiobutton(self.q8f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[7][2],
                               variable=self.qus8ans, value=1)
        qus8ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q8y[0], relx=0.1)
        qus8ans2 = Radiobutton(self.q8f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[7][3],
                               variable=self.qus8ans, value=2)
        qus8ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q8y[1], relx=0.1)
        qus8ans3 = Radiobutton(self.q8f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[7][4],
                               variable=self.qus8ans, value=3)
        qus8ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q8y[2], relx=0.1)

        pre_8_btn = Button(self.q8f, text="Previous", command=lambda: self.replaceFrame(self.q7f))
        pre_8_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_8_btn = Button(self.q8f, text="Next", command=lambda: self.replaceFrame(self.q9f))
        next_8_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 9
        q9y = self.place_answer()
        qus9Lable = Label(self.q9f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="9: " + ten_qus[8][1])
        qus9Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus9ans = IntVar()
        qus9ans1 = Radiobutton(self.q9f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[8][2],
                               variable=self.qus9ans, value=1)
        qus9ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q9y[0], relx=0.1)
        qus9ans2 = Radiobutton(self.q9f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[8][3],
                               variable=self.qus9ans, value=2)
        qus9ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q9y[1], relx=0.1)
        qus9ans3 = Radiobutton(self.q9f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[8][4],
                               variable=self.qus9ans, value=3)
        qus9ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q9y[2], relx=0.1)

        pre_9_btn = Button(self.q9f, text="Previous", command=lambda: self.replaceFrame(self.q8f))
        pre_9_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        next_9_btn = Button(self.q9f, text="Next", command=lambda: self.replaceFrame(self.q10f))
        next_9_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.50)

        # question 10
        q10y = self.place_answer()
        qus10Lable = Label(self.q10f, font=('Verdana', '13', 'bold'), bg='#dddddd', text="10: " + ten_qus[9][1])
        qus10Lable.place(bordermode=OUTSIDE, height=20, relwidth=1, y=20, relx=0.1)
        self.qus10ans = IntVar()
        qus10ans1 = Radiobutton(self.q10f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[9][2],
                                variable=self.qus10ans, value=1)
        qus10ans1.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q10y[0], relx=0.1)
        qus10ans2 = Radiobutton(self.q10f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[9][3],
                                variable=self.qus10ans, value=2)
        qus10ans2.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q10y[1], relx=0.1)
        qus10ans3 = Radiobutton(self.q10f, font=('Verdana', '13', 'bold'), bg='#dddddd', text=ten_qus[9][4],
                                variable=self.qus10ans, value=3)
        qus10ans3.place(bordermode=OUTSIDE, height=20, relwidth=0.3, y=q10y[2], relx=0.1)

        # button
        pre_10_btn = Button(self.q10f, text="Previous", command=lambda: self.replaceFrame(self.q9f))
        pre_10_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.30, y=300, relx=0.10)
        submit_btn = Button(self.q10f, text="submit", command=self.submint_check)
        submit_btn.place(bordermode=OUTSIDE, height=40, relwidth=0.40, y=300, relx=0.50)

    def clear_response(self):
        self.qus1ans.set(0)
        self.qus2ans.set(0)
        self.qus3ans.set(0)
        self.qus4ans.set(0)
        self.qus5ans.set(0)
        self.qus6ans.set(0)
        self.qus7ans.set(0)
        self.qus8ans.set(0)
        self.qus9ans.set(0)
        self.qus10ans.set(0)

    def submint_check(self):
        if self.qus1ans.get() == 1:
            quiz.modify_correct(ten_qus[0][0])
        elif self.qus1ans.get() == 0:
            quiz.modify_skip(ten_qus[0][0])
        else:
            quiz.modify_false(ten_qus[0][0])

        if self.qus2ans.get() == 1:
            quiz.modify_correct(ten_qus[1][0])
        elif self.qus2ans.get() == 0:
            quiz.modify_skip(ten_qus[1][0])
        else:
            quiz.modify_false(ten_qus[1][0])

        if self.qus3ans.get() == 1:
            quiz.modify_correct(ten_qus[2][0])
        elif self.qus3ans.get() == 0:
            quiz.modify_skip(ten_qus[2][0])
        else:
            quiz.modify_false(ten_qus[2][0])

        if self.qus4ans.get() == 1:
            quiz.modify_correct(ten_qus[3][0])
        elif self.qus4ans.get() == 0:
            quiz.modify_skip(ten_qus[3][0])
        else:
            quiz.modify_false(ten_qus[3][0])

        if self.qus5ans.get() == 1:
            quiz.modify_correct(ten_qus[4][0])
        elif self.qus5ans.get() == 0:
            quiz.modify_skip(ten_qus[4][0])
        else:
            quiz.modify_false(ten_qus[4][0])

        if self.qus6ans.get() == 1:
            quiz.modify_correct(ten_qus[5][0])
        elif self.qus6ans.get() == 0:
            quiz.modify_skip(ten_qus[5][0])
        else:
            quiz.modify_false(ten_qus[5][0])

        if self.qus7ans.get() == 1:
            quiz.modify_correct(ten_qus[6][0])
        elif self.qus7ans.get() == 0:
            quiz.modify_skip(ten_qus[6][0])
        else:
            quiz.modify_false(ten_qus[6][0])

        if self.qus8ans.get() == 1:
            quiz.modify_correct(ten_qus[7][0])
        elif self.qus8ans.get() == 0:
            quiz.modify_skip(ten_qus[7][0])
        else:
            quiz.modify_false(ten_qus[7][0])

        if self.qus9ans.get() == 1:
            quiz.modify_correct(ten_qus[8][0])
        elif self.qus9ans.get() == 0:
            quiz.modify_skip(ten_qus[8][0])
        else:
            quiz.modify_false(ten_qus[8][0])

        if self.qus10ans.get() == 1:
            quiz.modify_correct(ten_qus[9][0])
        elif self.qus10ans.get() == 0:
            quiz.modify_skip(ten_qus[9][0])
        else:
            quiz.modify_false(ten_qus[9][0])

        # self.master.destroy()
        # self.clear_response()

    def replaceFrame(self, frame):
        if self.currentFrame:
            self.currentFrame.place_forget()
        frame.place(bordermode=OUTSIDE, relheight=1, relwidth=1, relx=0, rely=0)
        self.currentFrame = frame

    def place_answer(self):
        l = [90, 130, 170]
        y = []
        y1 = random.choice(l)
        l.remove(y1)
        y.append(y1)
        y2 = random.choice(l)
        l.remove(y2)
        y.append(y2)
        y3 = l[0]
        y.append(y3)
        return y


def main():
    root = Tk()
    app = QuizGame(root)
    root.title('Comsci Quiz')
    root.minsize(400, 400)
    root.mainloop()


main()
