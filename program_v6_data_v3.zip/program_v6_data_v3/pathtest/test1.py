from database import sqlQuestion
from database import sqlTopic
import random
#
import PIL

# quiz = sqlQuestion.SqlQuestion()
# topic = sqlTopic.SqlTopic()
#
#
# def question_stat():
#     all_stat =[]
#     stat = []
#     question = quiz.select_all()
#     for qus in range(0, len(question)-1):
#         qus_body = question[qus][1]
#         ans_time = question[qus][5] + question[qus][6] + question[qus][7]
#         if ans_time == 0:
#             correct = "not answered"
#             ans_false = "not answered"
#         else:
#             correct = "{}%".format((question[qus][5]/ans_time)*100)
#             ans_false = "{}%".format((question[qus][5]/ans_time)*100)
#         stat = [qus_body, ans_time, correct, ans_false]
#         all_stat.append(stat)
#     return all_stat
#
# for re in quiz.select_all():
# # print(re)
# # stat = question_stat()
#     print(re)

def place_answer():
    l = [90, 130, 170]
    y = []
    y1 = random.choice(l)
    l.remove(y1)
    y.append(y1)
    y2 = random.choice(l)
    l.remove(y2)
    y.append(y2)
    y3 = l[0]
    y.append(y3)
    return y

re = place_answer()
print(re)